'use strict';

var Path = require('path');  
module.exports = {
    messages: { 
        parse () { 
             cc.log('执行转表请执行packages/excel2js/excel2json.bat');              
        }
    }
};
