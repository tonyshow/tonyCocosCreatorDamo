window.EnumMsgOrder = cc.Enum({   
    //一级弹框 
    MSG_FRIST_WINDOW : 2100,
    //二级弹框 
    MSG_SECOND_WINDOW : 2200    
});