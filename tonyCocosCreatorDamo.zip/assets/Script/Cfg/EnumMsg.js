window.EnumMsg = cc.Enum({ 
    LOGIN:1,
    CHAPTER:2,
});