window.EnumWindowType = cc.Enum({
    NONE :0,
    SCENE:1,
    MSG:2,
});