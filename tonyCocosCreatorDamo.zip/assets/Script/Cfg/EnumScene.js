window.EnumScene = cc.Enum({
    GAME_MAIN:1,
    HELLO_WORD:2,
});