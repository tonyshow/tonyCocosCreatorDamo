window.CfgScene = {
    gameMain:'gameMain',  
    helloworld:'helloworld',   
};

window.CfgMsg = {
    //登录界面
    login : "loginView",
}

window.GameCode = {
    OK:200,

    CONNECTOR:{
        
    }
}