window.EnumOrder = cc.Enum({ 
     //场景层级
    SCENE : 1000,
    //弹框 层级 
    MSG : 2000,
    //引导层级 
    GUIDE : 3000,
});